import { index, integer, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";

// The research snapshot stays in versioned source. Only user changes are stored.
export const termOverrides = sqliteTable("term_overrides", {
  ownerId: text("owner_id").notNull(),
  termId: text("term_id").notNull(),
  patchJson: text("patch_json").notNull(),
  revision: integer("revision").notNull(),
  updatedAt: text("updated_at").notNull(),
  lastMutationId: text("last_mutation_id").notNull(),
}, (table) => [primaryKey({ columns: [table.ownerId, table.termId] })]);

export const termHistory = sqliteTable("term_history", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  termId: text("term_id").notNull(),
  previousPatchJson: text("previous_patch_json").notNull(),
  nextPatchJson: text("next_patch_json").notNull(),
  revision: integer("revision").notNull(),
  action: text("action").notNull(),
  changedAt: text("changed_at").notNull(),
}, (table) => [index("history_owner_term_time").on(table.ownerId, table.termId, table.changedAt)]);
