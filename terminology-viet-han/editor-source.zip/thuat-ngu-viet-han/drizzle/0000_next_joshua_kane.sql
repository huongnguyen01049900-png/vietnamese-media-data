CREATE TABLE `term_history` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`term_id` text NOT NULL,
	`previous_patch_json` text NOT NULL,
	`next_patch_json` text NOT NULL,
	`revision` integer NOT NULL,
	`action` text NOT NULL,
	`changed_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `history_owner_term_time` ON `term_history` (`owner_id`,`term_id`,`changed_at`);--> statement-breakpoint
CREATE TABLE `term_overrides` (
	`owner_id` text NOT NULL,
	`term_id` text NOT NULL,
	`patch_json` text NOT NULL,
	`revision` integer NOT NULL,
	`updated_at` text NOT NULL,
	`last_mutation_id` text NOT NULL,
	PRIMARY KEY(`owner_id`, `term_id`)
);
