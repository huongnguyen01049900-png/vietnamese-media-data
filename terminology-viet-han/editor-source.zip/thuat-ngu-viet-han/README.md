# Thuật ngữ Việt–Hàn

Bảng nghiên cứu thuật ngữ chính trị và ngoại giao, gồm 266 dòng Việt–Hàn: bộ 167 và 99 mục bổ sung. Các dòng trùng khái niệm được giữ riêng theo mã đầu vào.

## Sử dụng

Trang được triển khai riêng tư bằng Sites. Người dùng đăng nhập bằng tài khoản ChatGPT, tìm kiếm hoặc lọc, mở một dòng rồi chọn **Lưu thay đổi**. Bản sửa được lưu trực tuyến theo tài khoản; mở lại cùng tài khoản trên thiết bị khác sẽ đọc cùng dữ liệu. Nhãn A/B/C và nguồn của bản nghiên cứu luôn được bảo toàn.

- **Xuất CSV**: các dòng đang lọc, gồm những thay đổi đã lưu.
- **Xuất JSON**: toàn bộ bản đang được trang tải, gồm các chứng cứ.
- **Tải Excel nghiên cứu**: bản Excel bàn giao, không tự cập nhật theo chỉnh sửa trên trang.
- **Khôi phục**: trả một mục về bản nghiên cứu ban đầu; lịch sử được giữ ở máy chủ.
- Xung đột phiên bản được báo để người dùng tải lại bản mới trước khi ghi tiếp.

GitHub lưu bản kết quả tại thời điểm bàn giao. Thay đổi trên trang không tự tạo commit GitHub hoặc ghi lại file Excel.

## Dữ liệu và phương pháp

`data/research.json` ghép dữ liệu định nghĩa, nhóm nội dung, đối chiếu Việt–Anh/Hàn–Anh và phân tích nguồn gốc từ. Dữ liệu này là bản nghiên cứu có mức chứng cứ, không phải danh mục 266 cặp đã được xác nhận hoàn toàn.

| Chứng cứ nguồn gốc | Việt | Hàn |
| --- | ---: | ---: |
| A — có nguồn cho thành tố quyết định | 161 | 64 |
| B — phân tích còn thiếu chứng cứ đầy đủ | 78 | 202 |
| C — còn điểm chưa chốt | 27 | 0 |

Có 48 dòng A/A. Chữ Hán/Hanja có `*` là dạng đối chiếu đề xuất chưa được chứng thực đầy đủ. Từ nguyên, tư cách thuật ngữ, tương đương nghĩa và nhóm nội dung là những kết luận riêng.

Nguồn Hán Việt ưu tiên: [Từ điển Hán Nôm Thi Viện](https://hvdic.thivien.net/). Có 12 dòng ghi chứng cứ mục từ cho cả dạng biểu thức, 241 dòng có chứng cứ thành tố, 13 dòng chưa có chứng cứ HVDic trong lượt này. Chưa có chứng cứ không có nghĩa từ điển không có mục từ. Các URL và phần hỗ trợ của từng nguồn nằm trong mỗi mục.

## Cấu trúc mã nguồn

- `app/page.tsx`, `app/globals.css`: giao diện nghiên cứu và trình chỉnh sửa.
- `app/api/terms/`: đọc, cập nhật và khôi phục mục.
- `app/api/history/`: lịch sử thay đổi của một mục thuộc tài khoản hiện tại.
- `lib/server-terms.ts`: kiểm tra dữ liệu, phân quyền và kiểm soát xung đột.
- `data/research.json`: bản dữ liệu nguồn được quản lý phiên bản.
- `db/schema.ts`, `drizzle/`: schema và migration D1.
- `public/downloads/`: file Excel nghiên cứu được phục vụ trên trang.
- `.openai/hosting.json`: cấu hình triển khai; kho mã nguồn bàn giao không kèm credential.

## Chạy và triển khai

Ứng dụng dùng Vinext/React và Cloudflare D1. `pnpm-lock.yaml` khóa phiên bản phụ thuộc. Trong môi trường Sites, dùng quy trình chính thức để cài phụ thuộc, tạo bản build, đồng bộ mã nguồn và triển khai. Các lệnh dự án: `npm run build`, `npm run db:generate`, `npm run dev`.

Migration chỉ tạo schema. Dữ liệu nghiên cứu đọc từ file JSON; chỉ chỉnh sửa và lịch sử được ghi vào D1. API production yêu cầu danh tính do Sites cung cấp. Môi trường phát triển có tài khoản thử riêng; nhánh thử không được đưa vào bản production. Hướng dẫn framework giữ tại `README.framework.md`.

Trước bàn giao đã kiểm tra kiểu TypeScript, build, dữ liệu 266 dòng, quyền truy cập, cách ly tài khoản, lưu/khôi phục và xung đột ghi. Xem trước bằng trình duyệt chưa thực hiện được vì dịch vụ preview của môi trường không khả dụng.
