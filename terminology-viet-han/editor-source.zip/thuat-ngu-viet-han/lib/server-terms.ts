import { and, desc, eq, sql } from "drizzle-orm";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { getDb } from "@/db";
import { termHistory, termOverrides } from "@/db/schema";
import researchData from "@/data/research.json";
import type { EditableTerm, ResearchDataset, TermRecord } from "@/lib/types";

type EditableFields = EditableTerm;
type TermPatch = Partial<EditableFields>;
type StoredOverride = typeof termOverrides.$inferSelect;
const dataset = researchData as unknown as ResearchDataset;
const seeds = new Map(dataset.records.map((record) => [record.id, record]));
const groupIds = new Set(dataset.groups.map((group) => group.id));
const fields: Record<keyof EditableFields, number> = {
  vi: 1500,
  ko: 1500,
  definitionVi: 15000,
  definitionKo: 15000,
  englishVi: 1500,
  englishKo: 1500,
  group: 80,
  subtype: 200,
  viClass: 300,
  koClass: 300,
  userNotes: 25000,
  extraSources: 15000,
  reviewStatus: 30,
};

export class ApiError extends Error {
  constructor(public status: number, message: string, public record?: TermRecord) {
    super(message);
  }
}

export function jsonResponse(body: unknown, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" },
  });
}

export function apiErrorResponse(error: unknown) {
  if (error instanceof ApiError) {
    return jsonResponse({ error: error.message, ...(error.record ? { record: error.record } : {}) }, error.status);
  }
  // Log no research data, identities, or request body.
  console.error("Terminology persistence request failed.");
  return jsonResponse({ error: "Chưa thể kết nối nơi lưu dữ liệu. Hãy thử lại; thay đổi chưa được xác nhận là đã lưu." }, 503);
}

export async function requestOwner(): Promise<{ ownerId: string; mode: "online" | "preview" }> {
  const user = await getChatGPTUser();
  if (user) return { ownerId: user.userId, mode: "online" };
  // Vite replaces this flag at build time. Hosted production never uses this identity.
  if (import.meta.env.DEV) return { ownerId: "local-preview-only", mode: "preview" };
  throw new ApiError(401, "Hãy đăng nhập bằng tài khoản ChatGPT để mở và lưu bảng nghiên cứu.");
}

export function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return;
  let incoming: URL;
  try { incoming = new URL(origin); } catch { throw new ApiError(403, "Nguồn gửi yêu cầu không hợp lệ."); }
  const destination = new URL(request.url);
  if (incoming.origin !== destination.origin) {
    throw new ApiError(403, "Không thể lưu từ một trang khác. Hãy mở lại trang nghiên cứu.");
  }
}

export async function readPayload(request: Request): Promise<Record<string, unknown>> {
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) {
    throw new ApiError(415, "Yêu cầu lưu cần dữ liệu JSON.");
  }
  const raw = await request.text();
  if (raw.length > 200000) throw new ApiError(413, "Nội dung chỉnh sửa quá dài.");
  let payload: unknown;
  try { payload = JSON.parse(raw); } catch { throw new ApiError(400, "Dữ liệu gửi lên chưa đúng định dạng."); }
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new ApiError(400, "Dữ liệu gửi lên chưa đúng định dạng.");
  }
  return payload as Record<string, unknown>;
}

export function validRevision(value: unknown): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 1_000_000_000) {
    throw new ApiError(400, "Thiếu phiên bản hiện tại của mục. Hãy tải lại bảng trước khi lưu.");
  }
  return value;
}

export function validPatch(value: unknown): TermPatch {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ApiError(400, "Thiếu các trường chỉnh sửa.");
  const patch: TermPatch = {};
  const entries = Object.entries(value);
  if (!entries.length) throw new ApiError(400, "Chưa có thay đổi để lưu.");
  for (const [key, value] of entries) {
    if (!Object.hasOwn(fields, key)) throw new ApiError(400, `Không được sửa trường ${key.slice(0, 60)}.`);
    const field = key as keyof EditableFields;
    if (typeof value !== "string" || value.length > fields[field] || value.includes("\0")) {
      throw new ApiError(400, `Nội dung trường ${field} chưa hợp lệ hoặc quá dài.`);
    }
    if ((field === "vi" || field === "ko") && !value.trim()) throw new ApiError(400, "Thuật ngữ Việt và Hàn không được để trống.");
    if (field === "group" && !groupIds.has(value)) throw new ApiError(400, "Nhóm phân loại chưa hợp lệ.");
    if (field === "reviewStatus" && !["pending", "reviewed", "needs_check"].includes(value)) {
      throw new ApiError(400, "Trạng thái rà soát chưa hợp lệ.");
    }
    // Keys have been checked against a closed allow-list.
    Object.assign(patch, { [field]: value });
  }
  return patch;
}

function seedFor(id: string): TermRecord {
  const seed = seeds.get(id);
  if (!seed) throw new ApiError(404, "Không tìm thấy mã thuật ngữ này.");
  return seed;
}

function readStoredPatch(row?: StoredOverride): TermPatch {
  if (!row) return {};
  const parsed: unknown = JSON.parse(row.patchJson);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Invalid stored override.");
  // Stored records are still limited to editable properties when reading them.
  return Object.fromEntries(Object.entries(parsed).filter(([key]) => Object.hasOwn(fields, key))) as TermPatch;
}

function materialize(seed: TermRecord, row?: StoredOverride): TermRecord {
  const patch = readStoredPatch(row);
  return {
    ...seed,
    ...patch,
    revision: row?.revision ?? 0,
    updatedAt: row?.updatedAt ?? null,
    edited: Object.keys(patch).length > 0,
  };
}

async function currentOverride(ownerId: string, id: string) {
  return (await getDb().select().from(termOverrides).where(and(
    eq(termOverrides.ownerId, ownerId), eq(termOverrides.termId, id),
  )).limit(1))[0];
}

export async function listTerms(ownerId: string, mode: "online" | "preview") {
  const overrides = await getDb().select().from(termOverrides).where(eq(termOverrides.ownerId, ownerId));
  const byId = new Map(overrides.map((row) => [row.termId, row]));
  return {
    ...dataset,
    mode,
    records: dataset.records.map((seed) => materialize(seed, byId.get(seed.id))),
  };
}

export async function saveTerm(ownerId: string, id: string, revision: number, incomingPatch: TermPatch | null) {
  const seed = seedFor(id);
  const previous = await currentOverride(ownerId, id);
  if ((previous?.revision ?? 0) !== revision) {
    throw new ApiError(409, "Mục này đã được thay đổi trong một cửa sổ khác. Hãy xem bản mới trước khi lưu lại.", materialize(seed, previous));
  }
  const oldPatch = readStoredPatch(previous);
  const combined = incomingPatch === null ? {} : { ...oldPatch, ...incomingPatch };
  // Storing only actual differences makes reset and the edited label unambiguous.
  const patch = Object.fromEntries(Object.entries(combined).filter(([key, value]) => value !== seed[key as keyof EditableFields]));
  const patchJson = JSON.stringify(patch);
  const now = new Date().toISOString();
  const mutationId = crypto.randomUUID();
  const nextRevision = revision + 1;
  const db = getDb();
  const write = previous
    ? db.update(termOverrides).set({ patchJson, revision: nextRevision, updatedAt: now, lastMutationId: mutationId })
      .where(and(eq(termOverrides.ownerId, ownerId), eq(termOverrides.termId, id), eq(termOverrides.revision, revision))).returning()
    : db.insert(termOverrides).values({ ownerId, termId: id, patchJson, revision: nextRevision, updatedAt: now, lastMutationId: mutationId })
      .onConflictDoNothing().returning();

  // D1 executes the batch atomically. History is inserted only if this exact
  // compare-and-swap succeeded, identified by the random lastMutationId.
  const history = db.insert(termHistory).select(db.select({
    id: sql<string>`${mutationId}`.as("id"),
    ownerId: termOverrides.ownerId,
    termId: termOverrides.termId,
    previousPatchJson: sql<string>`${JSON.stringify(oldPatch)}`.as("previous_patch_json"),
    nextPatchJson: termOverrides.patchJson,
    revision: termOverrides.revision,
    action: sql<string>`${incomingPatch === null ? "reset" : "edit"}`.as("action"),
    changedAt: termOverrides.updatedAt,
  }).from(termOverrides).where(and(
    eq(termOverrides.ownerId, ownerId), eq(termOverrides.termId, id), eq(termOverrides.lastMutationId, mutationId),
  )));
  const [changed] = await db.batch([write, history]);
  if (!changed.length) {
    const latest = await currentOverride(ownerId, id);
    throw new ApiError(409, "Mục này vừa được thay đổi trong một cửa sổ khác. Bản mới đã được trả về để bạn kiểm tra.", materialize(seed, latest));
  }
  return materialize(seed, changed[0]);
}

export async function listHistory(ownerId: string, id: string) {
  seedFor(id);
  const history = await getDb().select().from(termHistory).where(and(
    eq(termHistory.ownerId, ownerId), eq(termHistory.termId, id),
  )).orderBy(desc(termHistory.revision)).limit(30);
  return history.map(({ revision, action, changedAt, previousPatchJson, nextPatchJson }) => ({
    revision, action, changedAt,
    previousPatch: JSON.parse(previousPatchJson),
    nextPatch: JSON.parse(nextPatchJson),
  }));
}
