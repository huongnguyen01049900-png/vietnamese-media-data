export type ReviewStatus = 'pending' | 'reviewed' | 'needs_check';
export type Confidence = 'A' | 'B' | 'C';
export type VietnameseDefinition = {
  working_definition: string; definition_vi_quote: string; definition_vi_paraphrase: string;
  source_title: string; source_url: string; source_language: string; source_kind: string;
  status: string; status_label: string; notes: string; definition_origin: string;
  definition_content_type: string; checked_at: string; source_code: string;
  definition_origin_label?: string; source_location?: string; check_method?: string;
};
export type KoreanDictionaryDefinition = {
  status: string; status_label: string; headword: string; hanja: string; sense_number: string;
  dictionary_name: string; definition_ko_quote: string; definition_ko_paraphrase: string;
  definition_vi_translation: string; source_url: string; source_title: string;
  source_language: string; definition_relation_note: string; check_method: string;
  checked_at: string; source_code: string; license: string; license_url: string;
  source_access_mode?: string; source_snapshot_date?: string; mirror_url?: string;
  verification_note?: string; access_label?: string;
  official_entry_url?: string; verification_status?: string;
  original_language_form?: string;
};
export type SpecializedTermEntry = KoreanDictionaryDefinition & {
  publisher: string; domain: string; english: string; entry_type: string;
};
export type EnglishBranch = {
  english: string; english_display: string; source_term: string; source_title: string;
  source_url: string; source_language: string; evidence_label: string; evidence_kind: string;
  evidence_note: string; sense_vi: string;
};
export type EnglishComparison = {
  vi_en: EnglishBranch; ko_en: EnglishBranch; form_label: string; sense_label: string;
  verdict_label: string; notes: string; strict_match_confirmed: boolean;
  verdict: string; sense_relation: string; en_form_relation: string;
};
export type EditableTerm = {
  vi: string; ko: string; definitionVi: string; definitionKo: string;
  englishVi: string; englishKo: string; group: string; subtype: string;
  viClass: string; koClass: string; userNotes: string; extraSources: string;
  reviewStatus: ReviewStatus;
};
export type ResearchSource = {
  code: string; title: string; url: string; evidence: string;
  language: string; role: string;
};
export type TermEvidence = {
  viConfidence: Confidence; koConfidence: Confidence; pairState: string;
  viSegments: string; koSegments: string; viNotes: string; koNotes: string;
  hvdicStatus: string; hvdicNote: string; englishVerdict: string;
  englishNotes: string; classificationNotes: string; sourceNote: string;
  sources: ResearchSource[];
  definitionViStatus: string; definitionKoStatus: string;
  dictionaryViStatus: string; dictionaryKoStatus: string;
  normalizationNotes: string; namesNotes: string; koLexicalClass: string;
};
export type TermRecord = EditableTerm & {
  id: string; stt: number; revision: number; updatedAt: string | null;
  edited: boolean; evidence: TermEvidence; original: EditableTerm;
  conceptId: string; origin: string;
  referenceDefinitions?: { vi: VietnameseDefinition; ko: KoreanDictionaryDefinition; generalEntries?: KoreanDictionaryDefinition[]; specialized: SpecializedTermEntry[] };
  englishComparison?: EnglishComparison;
};
export type ResearchGroup = {
  id: string; label: string; koLabel: string; definition: string;
  subtypes: string[]; exclude: string;
};
export type ResearchDataset = {
  title: string; version: string; records: TermRecord[];
  groups: ResearchGroup[]; stats: Record<string, unknown>;
  methodology: { rules: string[][]; classificationRules: string[]; warning: string };
};
export type TermsResponse = ResearchDataset & { mode: 'online' | 'preview' };
export const EDITABLE_FIELDS = [
  'vi', 'ko', 'definitionVi', 'definitionKo', 'englishVi', 'englishKo',
  'group', 'subtype', 'viClass', 'koClass', 'userNotes', 'extraSources', 'reviewStatus',
] as const;
