export type ReviewStatus = 'pending' | 'reviewed' | 'needs_check';
export type Confidence = 'A' | 'B' | 'C';
export type EditableTerm = {
  vi: string; ko: string; definitionVi: string; definitionKo: string;
  englishVi: string; englishKo: string; group: string; subtype: string;
  viClass: string; koClass: string; userNotes: string; extraSources: string;
  reviewStatus: ReviewStatus;
};
export type ResearchSource = {
  code: string; title: string; url: string; evidence: string;
  language: string; role: string;
};
export type TermEvidence = {
  viConfidence: Confidence; koConfidence: Confidence; pairState: string;
  viSegments: string; koSegments: string; viNotes: string; koNotes: string;
  hvdicStatus: string; hvdicNote: string; englishVerdict: string;
  englishNotes: string; classificationNotes: string; sourceNote: string;
  sources: ResearchSource[];
  definitionViStatus: string; definitionKoStatus: string;
  dictionaryViStatus: string; dictionaryKoStatus: string;
  normalizationNotes: string; namesNotes: string; koLexicalClass: string;
};
export type TermRecord = EditableTerm & {
  id: string; stt: number; revision: number; updatedAt: string | null;
  edited: boolean; evidence: TermEvidence; original: EditableTerm;
  conceptId: string; origin: string;
};
export type ResearchGroup = {
  id: string; label: string; koLabel: string; definition: string;
  subtypes: string[]; exclude: string;
};
export type ResearchDataset = {
  title: string; version: string; records: TermRecord[];
  groups: ResearchGroup[]; stats: Record<string, unknown>;
  methodology: { rules: string[][]; classificationRules: string[]; warning: string };
};
export type TermsResponse = ResearchDataset & { mode: 'online' | 'preview' };
export const EDITABLE_FIELDS = [
  'vi', 'ko', 'definitionVi', 'definitionKo', 'englishVi', 'englishKo',
  'group', 'subtype', 'viClass', 'koClass', 'userNotes', 'extraSources', 'reviewStatus',
] as const;
