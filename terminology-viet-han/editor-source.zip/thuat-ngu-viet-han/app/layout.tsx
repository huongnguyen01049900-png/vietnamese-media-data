import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Thuật ngữ Việt–Hàn | Bảng nghiên cứu",
  description: "Bảng nghiên cứu thuật ngữ chính trị và ngoại giao Việt–Hàn: định nghĩa, nhóm nội dung, đối chiếu tiếng Anh và nguồn gốc từ.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{children}</body></html>;
}
