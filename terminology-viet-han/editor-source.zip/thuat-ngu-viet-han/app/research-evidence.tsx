import type { EnglishBranch, KoreanDictionaryDefinition, TermRecord } from '@/lib/types';

export function SourceLinks({ urls, label }: { urls: string; label?: string }) {
  const links = (urls || '').split(/\s+/).filter(url => /^https?:\/\//i.test(url));
  return <div className="reference-links">{links.map((url, i) => <a key={url} href={url} target="_blank" rel="noopener noreferrer">{label || (links.length > 1 ? `Nguồn ${i + 1}` : 'Mở nguồn')} ↗</a>)}</div>;
}

function VerificationDetails({ entry }: { entry: KoreanDictionaryDefinition }) {
  return <>{(entry.access_label || entry.source_snapshot_date || entry.verification_note) && <div className="reference-note">
    {entry.access_label && <p><strong>Cách tiếp cận nguồn:</strong> {entry.access_label}</p>}
    {entry.source_snapshot_date && <p><strong>Ngày bản dữ liệu:</strong> {entry.source_snapshot_date}</p>}
    {entry.verification_note && <p>{entry.verification_note}</p>}
  </div>}
  {entry.mirror_url && <SourceLinks urls={entry.mirror_url} label="Bản dữ liệu lưu lại" />}
  {entry.official_entry_url && entry.official_entry_url !== entry.source_url && <SourceLinks urls={entry.official_entry_url} label="Đường dẫn mục từ tại từ điển gốc" />}
  {entry.check_method && <details className="research-detail"><summary>Cách kiểm tra · {entry.checked_at || 'Xem nguồn'}</summary><p>{entry.check_method}</p></details>}
  </>;
}

export function DefinitionsPanel({ row }: { row: TermRecord }) {
  const refs = row.referenceDefinitions;
  if (!refs) return <p className="analysis-note">Chưa có hồ sơ định nghĩa bổ sung cho mục này.</p>;
  const { vi, ko } = refs;
  const component = ko.status === 'component_only';
  return <>
    <div className="editor-notice"><p>Định nghĩa được giữ theo đúng mục từ và nghĩa của nguồn. Phần diễn giải hoặc bản dịch của nghiên cứu có nhãn riêng.</p></div>
    <div className="definition-columns">
      <article className="definition-card">
        <span className="mini-label">PHÍA VIỆT</span><h3>{row.original.vi}</h3>
        <span className={`definition-status ${vi.status === 'working_only' || vi.status === 'unverified' ? 'pending' : ''}`}>{vi.status_label}</span>
        <section><h4>Nghĩa làm việc trong nghiên cứu</h4><p>{row.definitionVi || 'Chưa có nghĩa làm việc.'}</p></section>
        {vi.definition_vi_quote && <section><h4>Trích định nghĩa từ nguồn</h4><blockquote>{vi.definition_vi_quote}</blockquote></section>}
        {vi.definition_vi_paraphrase && <section><h4>Diễn giải khái niệm theo nguồn</h4><p>{vi.definition_vi_paraphrase}</p>{vi.definition_origin_label && <p className="reference-mini-status">{vi.definition_origin_label}</p>}</section>}
        {!vi.definition_vi_quote && !vi.definition_vi_paraphrase && <p className="definition-empty">Chưa xác minh định nghĩa trực tiếp. Câu nghĩa làm việc ở trên là phần diễn giải của nghiên cứu.</p>}
        <dl className="definition-meta"><dt>Loại nội dung</dt><dd>{vi.definition_content_type || 'Chưa xác minh'}</dd><dt>Ngôn ngữ nguồn</dt><dd>{vi.source_language || '—'}</dd><dt>Nguồn</dt><dd>{vi.source_title || 'Chưa có nguồn định nghĩa trực tiếp'}</dd></dl>
        {vi.source_location && <p className="reference-note">Vị trí: {vi.source_location}</p>}<SourceLinks urls={vi.source_url} label={vi.source_code ? `Nguồn ${vi.source_code}` : undefined} />
        {vi.notes && <p className="reference-note">{vi.notes}</p>}
      </article>
      <article className="definition-card">
        <span className="mini-label">TỪ ĐIỂN QUỐC NGỮ HÀN QUỐC</span><h3 lang="ko">{row.original.ko}</h3>
        <span className={`definition-status ${ko.source_access_mode === 'mirrored_export' || !['exact_definition','variant_definition'].includes(ko.status) ? 'pending' : ''}`}>{ko.status_label}</span>
        <dl className="definition-meta"><dt>Từ điển</dt><dd lang="ko">{ko.dictionary_name || 'Chưa xác minh mục từ trong từ điển quốc gia'}</dd><dt>{component ? 'Thành tố đã tra' : 'Mục từ đã tra'}</dt><dd lang="ko">{ko.headword || '—'}{ko.hanja ? ` (${ko.hanja})` : ''}</dd><dt>Số nghĩa</dt><dd>{ko.sense_number || 'Không có số nghĩa được ghi'}</dd></dl>
        {ko.original_language_form && ko.original_language_form !== ko.hanja && <p className="reference-note">Nguyên ngữ trong mục nguồn: <span lang="ko">{ko.original_language_form}</span></p>}
        {component && <p className="definition-empty">Định nghĩa sau chỉ thuộc thành tố đã tra, chưa phải định nghĩa toàn thuật ngữ.</p>}
        {ko.definition_ko_quote && <section><h4>{component ? 'Định nghĩa gốc của thành tố' : 'Định nghĩa tiếng Hàn từ nguồn'}</h4><blockquote lang="ko">{ko.definition_ko_quote}</blockquote></section>}
        {ko.definition_ko_paraphrase && <section><h4>Diễn giải tiếng Hàn của nghiên cứu</h4><p lang="ko">{ko.definition_ko_paraphrase}</p></section>}
        {ko.definition_vi_translation && <section><h4>Bản dịch nghĩa sang tiếng Việt của nghiên cứu</h4><p>{ko.definition_vi_translation}</p></section>}
        {!ko.definition_ko_quote && !ko.definition_ko_paraphrase && <p className="definition-empty">Chưa có định nghĩa từ điển đã xác minh cho toàn biểu thức. Nghĩa tiếng Hàn ở thẻ Nội dung vẫn được giữ riêng như nghĩa làm việc.</p>}
        <SourceLinks urls={ko.source_url} label="Nguồn đã dùng để đọc định nghĩa" />
        <p className="reference-note">{ko.definition_relation_note}</p>
        <VerificationDetails entry={ko} />
        {ko.license && <p className="reference-credit">Nguồn: 국립국어원 · <a href={ko.license_url} target="_blank" rel="noopener noreferrer">{ko.license}</a>. Phần định nghĩa và bản dịch nghĩa của nghiên cứu được ghi nguồn và sử dụng theo giấy phép tương ứng.</p>}
      </article>
    </div>
    {!!refs.generalEntries?.filter(entry => entry.source_url !== ko.source_url || entry.sense_number !== ko.sense_number).length && <section className="specialized-section"><h3>Mục từ quốc ngữ khác để đối chiếu</h3><div className="specialized-list">{refs.generalEntries.filter(entry => entry.source_url !== ko.source_url || entry.sense_number !== ko.sense_number).map((entry, i) => <article className="definition-card" key={`general-${i}`}>
      <span className="mini-label" lang="ko">{entry.dictionary_name}</span><h3 lang="ko">{entry.headword}{entry.hanja ? ` (${entry.hanja})` : ''}</h3><span className="definition-status pending">{entry.status_label}</span>
      {entry.sense_number && <p className="reference-note">Nghĩa: {entry.sense_number}</p>}
      {entry.definition_ko_quote && <blockquote lang="ko">{entry.definition_ko_quote}</blockquote>}
      {entry.definition_ko_paraphrase && <p lang="ko">{entry.definition_ko_paraphrase}</p>}
      {entry.definition_vi_translation && <p className="reference-note">Bản dịch nghĩa của nghiên cứu: {entry.definition_vi_translation}</p>}
      <p className="reference-note">{entry.definition_relation_note}</p><SourceLinks urls={entry.source_url} label="Nguồn đã đọc" /><VerificationDetails entry={entry} />
      {entry.license && <p className="reference-credit">Nguồn: 국립국어원 · <a href={entry.license_url} target="_blank" rel="noopener noreferrer">{entry.license}</a></p>}
    </article>)}</div></section>}
    <section className="specialized-section"><h3>Từ điển thuật ngữ chuyên ngành <span lang="ko">용어사전</span></h3>
      {refs.specialized?.length ? <div className="specialized-list">{refs.specialized.map((entry, i) => <article className="definition-card" key={`${entry.source_url}-${i}`}>
        <span className="mini-label">{entry.domain || 'THUẬT NGỮ CHUYÊN NGÀNH'}</span><h3 lang="ko">{entry.headword}</h3>
        <span className={`definition-status ${entry.entry_type !== 'definition' || !['exact_definition','variant_definition'].includes(entry.status) ? 'pending' : ''}`}>{entry.status_label}</span>
        <dl className="definition-meta"><dt>Từ điển / thuật ngữ tập</dt><dd>{entry.dictionary_name}</dd><dt>Đơn vị biên soạn / nguồn gốc</dt><dd>{entry.publisher || entry.source_title}</dd>{entry.english && <><dt>Đối dịch Anh trong mục</dt><dd>{entry.english}</dd></>}</dl>
        {entry.status === 'component_only' && <p className="definition-empty">Chứng cứ chỉ cho thành tố, chưa xác nhận toàn biểu thức.</p>}
        {entry.definition_ko_quote && <section><h4>Trích định nghĩa tiếng Hàn</h4><blockquote lang="ko">{entry.definition_ko_quote}</blockquote></section>}
        {entry.definition_ko_paraphrase && <section><h4>Diễn giải tiếng Hàn của nghiên cứu</h4><p lang="ko">{entry.definition_ko_paraphrase}</p></section>}
        {entry.definition_vi_translation && <section><h4>Diễn giải nghĩa bằng tiếng Việt của nghiên cứu</h4><p>{entry.definition_vi_translation}</p></section>}
        {!entry.definition_ko_quote && !entry.definition_ko_paraphrase && <p className="definition-empty">Mục nguồn hiện chỉ hỗ trợ tên gọi hoặc đối dịch; chưa cung cấp định nghĩa đã xác minh.</p>}
        <p className="reference-note">{entry.definition_relation_note}</p><SourceLinks urls={entry.source_url} label="Mở mục chuyên ngành" /><VerificationDetails entry={entry} />
        {entry.license && <p className="reference-credit">{entry.publisher} · <a href={entry.license_url} target="_blank" rel="noopener noreferrer">{entry.license}</a></p>}
      </article>)}</div> : <p className="definition-empty">Chưa xác minh được mục từ chuyên ngành phù hợp trong lượt kiểm tra này. Trạng thái này không khẳng định thuật ngữ không tồn tại.</p>}
    </section>
  </>;
}

export function EvidenceTable({ rows, view, onOpen }: { rows: TermRecord[]; view: 'definitions' | 'english'; onOpen: (row: TermRecord) => void }) {
  return <table className={`reference-table ${view}-table`}><thead><tr><th className="number-column">STT / Mã</th><th>Thuật ngữ Việt–Hàn</th>{view === 'definitions' ? <><th>Khái niệm phía Việt</th><th>Định nghĩa Hàn từ từ điển</th><th>Phạm vi chứng cứ</th></> : <><th>Việt → Anh</th><th>Hàn → Anh</th><th>Kết luận theo nghĩa</th></>}</tr></thead><tbody>{rows.map(row => {
    const vi = row.referenceDefinitions?.vi, ko = row.referenceDefinitions?.ko, en = row.englishComparison;
    const specialized = row.referenceDefinitions?.specialized?.filter(entry => entry.entry_type === 'definition' && ['exact_definition','variant_definition'].includes(entry.status)) || [];
    const primary = ko && ['exact_definition','variant_definition'].includes(ko.status) && ko.source_access_mode !== 'mirrored_export' ? ko : specialized[0] || ko;
    return <tr key={row.id} onClick={() => onOpen(row)}><td className="number-column"><span className="row-number">{row.stt}</span><span className="row-code">{row.id}</span></td><td><button className="term-button" onClick={event => { event.stopPropagation(); onOpen(row); }}><strong>{row.vi}</strong><span className="korean-term" lang="ko">{row.ko}</span></button>{row.edited && <span className="edited-indicator">Đã sửa bản làm việc</span>}</td>{view === 'definitions' ? <><td><p className="reference-summary">{vi?.definition_vi_paraphrase || vi?.definition_vi_quote || row.definitionVi}</p><span className="reference-mini-status">{vi?.status_label || 'Nghĩa làm việc'}</span></td><td><p className="reference-summary" lang="ko">{primary?.definition_ko_quote || primary?.definition_ko_paraphrase || 'Chưa có định nghĩa từ điển đã xác minh'}</p><span className="reference-mini-status" lang="ko">{primary?.dictionary_name || 'Cần kiểm tra'}</span>{primary?.headword && <small className="reference-headword" lang="ko">Mục tra: {primary.headword}</small>}</td><td><span className="reference-mini-status">{primary?.status_label || 'Chưa xác minh'}</span>{specialized.length > 0 && <small className="reference-headword">Có {specialized.length} nguồn định nghĩa chuyên ngành</small>}<span className="reference-open">Xem định nghĩa và nguồn →</span></td></> : <><td><strong className="reference-english">{row.englishVi || 'Chưa có đối dịch'}</strong><span className="reference-mini-status">{en?.vi_en.evidence_label || 'Chưa xác minh ánh xạ'}</span><p className="reference-source-name">{en?.vi_en.source_title}</p></td><td><strong className="reference-english">{row.englishKo || 'Chưa có đối dịch'}</strong><span className="reference-mini-status">{en?.ko_en.evidence_label || 'Chưa xác minh ánh xạ'}</span><p className="reference-source-name">{en?.ko_en.source_title}</p></td><td><span className="reference-mini-status">{en?.verdict_label || row.evidence.englishVerdict}</span><p className="reference-source-name">{en?.form_label}<br />{en?.sense_label}</p><span className="reference-open">Xem hai nhánh và nguồn →</span></td></>}</tr>;
  })}</tbody></table>;
}

function EnglishBranchCard({ branch, label, current, original }: { branch: EnglishBranch; label: string; current: string; original: string }) {
  return <article className="definition-card"><span className="mini-label">{label}</span><h3>{branch.source_term || original}</h3><div className="english-equivalent">{branch.english_display || branch.english || 'Chưa có dạng Anh được xác minh'}</div><span className="definition-status">{branch.evidence_label}</span>{current !== (branch.english_display || branch.english) && <p className="definition-empty">Dạng Anh trong bản làm việc đã được sửa thành: <strong>{current}</strong>. Chứng cứ dưới đây thuộc bản đối chiếu ban đầu.</p>}<section><h4>Nghĩa được đối chiếu</h4><p>{branch.sense_vi || 'Xem định nghĩa nghĩa đã chọn của mục.'}</p></section><p className="reference-note">{branch.evidence_note}</p><dl className="definition-meta"><dt>Nguồn</dt><dd>{branch.source_title || 'Chưa có nguồn ánh xạ trực tiếp'}</dd><dt>Ngôn ngữ nguồn</dt><dd>{branch.source_language || '—'}</dd></dl><SourceLinks urls={branch.source_url} /></article>;
}

export function EnglishPanel({ row }: { row: TermRecord }) {
  const en = row.englishComparison;
  if (!en) return <p className="analysis-note">Chưa có hồ sơ hai nhánh đối chiếu cho mục này.</p>;
  return <><div className="editor-notice"><p>Đọc hai ánh xạ riêng, sau đó kiểm tra cùng nghĩa. Trùng chữ tiếng Anh chỉ là một điều kiện; nguồn chỉ mô tả khái niệm chưa tự chứng minh phép đối dịch.</p></div><div className="definition-columns"><EnglishBranchCard branch={en.vi_en} label="VIỆT → ANH" current={row.englishVi} original={row.original.vi} /><EnglishBranchCard branch={en.ko_en} label="HÀN → ANH" current={row.englishKo} original={row.original.ko} /></div><div className="comparison-conclusion"><span className="mini-label">KẾT LUẬN TRONG BẢN NGHIÊN CỨU</span><h3>{en.verdict_label}</h3><dl><dt>Hình thức Anh</dt><dd>{en.form_label}</dd><dt>Nội hàm/ngữ cảnh</dt><dd>{en.sense_label}</dd></dl><p>{en.notes}</p></div></>;
}
