import { apiErrorResponse, jsonResponse, listTerms, requestOwner } from "@/lib/server-terms";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const { ownerId, mode } = await requestOwner();
    return jsonResponse(await listTerms(ownerId, mode));
  } catch (error) { return apiErrorResponse(error); }
}
