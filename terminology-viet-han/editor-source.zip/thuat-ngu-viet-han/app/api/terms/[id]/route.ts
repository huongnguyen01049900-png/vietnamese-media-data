import { apiErrorResponse, assertSameOrigin, jsonResponse, readPayload, requestOwner, saveTerm, validPatch, validRevision } from "@/lib/server-terms";

export const dynamic = "force-dynamic";
type RouteContext = { params: Promise<{ id: string }> };

export async function PUT(request: Request, context: RouteContext) {
  try {
    assertSameOrigin(request);
    const { ownerId } = await requestOwner();
    const { id } = await context.params;
    const body = await readPayload(request);
    const record = await saveTerm(ownerId, id, validRevision(body.revision), validPatch(body.patch));
    return jsonResponse({ record });
  } catch (error) { return apiErrorResponse(error); }
}

export async function DELETE(request: Request, context: RouteContext) {
  try {
    assertSameOrigin(request);
    const { ownerId } = await requestOwner();
    const { id } = await context.params;
    const body = await readPayload(request);
    const record = await saveTerm(ownerId, id, validRevision(body.revision), null);
    return jsonResponse({ record });
  } catch (error) { return apiErrorResponse(error); }
}
