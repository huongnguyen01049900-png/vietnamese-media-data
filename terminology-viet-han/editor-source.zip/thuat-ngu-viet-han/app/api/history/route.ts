import { ApiError, apiErrorResponse, jsonResponse, listHistory, requestOwner } from "@/lib/server-terms";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { ownerId } = await requestOwner();
    const id = new URL(request.url).searchParams.get("id");
    if (!id) throw new ApiError(400, "Cần mã thuật ngữ để xem lịch sử.");
    return jsonResponse({ history: await listHistory(ownerId, id) });
  } catch (error) { return apiErrorResponse(error); }
}
